-- Notices:
--
-- Copyright 2020 United States Government as represented by the Administrator of the National Aeronautics and Space Administration. All Rights Reserved.

-- Disclaimers
-- No Warranty: THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE. THIS AGREEMENT DOES NOT, IN ANY MANNER, CONSTITUTE AN ENDORSEMENT BY GOVERNMENT AGENCY OR ANY PRIOR RECIPIENT OF ANY RESULTS, RESULTING DESIGNS, HARDWARE, SOFTWARE PRODUCTS OR ANY OTHER APPLICATIONS RESULTING FROM USE OF THE SUBJECT SOFTWARE.  FURTHER, GOVERNMENT AGENCY DISCLAIMS ALL WARRANTIES AND LIABILITIES REGARDING THIRD-PARTY SOFTWARE, IF PRESENT IN THE ORIGINAL SOFTWARE, AND DISTRIBUTES IT "AS IS."

-- Waiver and Indemnity:  RECIPIENT AGREES TO WAIVE ANY AND ALL CLAIMS AGAINST THE UNITED STATES GOVERNMENT, ITS CONTRACTORS AND SUBCONTRACTORS, AS WELL AS ANY PRIOR RECIPIENT.  IF RECIPIENT'S USE OF THE SUBJECT SOFTWARE RESULTS IN ANY LIABILITIES, DEMANDS, DAMAGES, EXPENSES OR LOSSES ARISING FROM SUCH USE, INCLUDING ANY DAMAGES FROM PRODUCTS BASED ON, OR RESULTING FROM, RECIPIENT'S USE OF THE SUBJECT SOFTWARE, RECIPIENT SHALL INDEMNIFY AND HOLD HARMLESS THE UNITED STATES GOVERNMENT, ITS CONTRACTORS AND SUBCONTRACTORS, AS WELL AS ANY PRIOR RECIPIENT, TO THE EXTENT PERMITTED BY LAW.  RECIPIENT'S SOLE REMEDY FOR ANY SUCH MATTER SHALL BE THE IMMEDIATE, UNILATERAL TERMINATION OF THIS AGREEMENT.


{-# LANGUAGE DisambiguateRecordFields #-}
{-# LANGUAGE ScopedTypeVariables #-}

module ReFlow
  ( main,
  )
where

import AbsPVSLang (RProgram,FunName,Decl(..),Arg,AExpr,FAExpr)
import AbstractSemantics (SemanticConfiguration(..),fixpointSemantics,botInterp,semantics,stableConditions,maxRoundOffError)
import AbstractDomain (Conditions)
import Common.DecisionPath (LDecisionPath)
import Common.ControlFlow (ControlFlow(..))
import ErrM (errify)
import PVSTypes (PVSType(..))
import FramaC.PrettyPrint (genFramaCFile)
import FramaC.PrecisaPrelude (precisaPreludeContent)
import Options (Options(..),parseOptions)
import PPExt (render,vcat)
import Kodiak.Runner (KodiakResult(..))
import Kodiak.Paver (SearchParameters(..))
import Prelude hiding ((<>))
import PVSCert (genFpProgFile,genCertFile,genNumCertFile,genExprCertFile,printExprFunCert)
import Parser.Parser (parseFileToRealProgram,parseFileToSpec)
import System.FilePath (dropFileName,takeBaseName)
import Transformation (transformProgramSymb)
import TransformationUtils (computeErrorGuards)
import Translation.Real2Float (real2fpProg)

import qualified PRECiSA (computeAllErrorsInKodiak)

main :: IO ()
main = do
  options <- parseOptions
  generateCProg options

parseRealProg :: FilePath -> IO RProgram
parseRealProg fileprog = do
  errparseProg <- parseFileToRealProgram fileprog
  errify error errparseProg

generateCProg :: Options -> IO ()
generateCProg
  Options
    { optRealProgramFile     = prog
    , optRealInputRangeFile  = inputs
    , targetFormat           = fprec }
  = case fprec of
    "double" ->  real2FPC prog inputs FPDouble
    "single" ->  real2FPC prog inputs FPSingle
    _ -> error ""


real2FPC :: FilePath -> FilePath -> PVSType -> IO ()
real2FPC fileprog filespec fp = do
  realProg <- parseRealProg fileprog

  -- fp progam
  let decls = real2fpProg fp realProg
  errparseSpec <- parseFileToSpec decls filespec
  spec <- errify fail errparseSpec
  let dpsNone = map initDpsToNone decls

  -- transfromed program --
  let tranProgTuples = transformProgramSymb realProg decls

  -- program semantics
  let progSemStable = fixpointSemantics decls (botInterp decls) 3 semConf dpsNone
  let progStableConds = map (stableConditions . semantics) progSemStable
  let progSymbRoundOffErrs = map (maxRoundOffError . semantics) progSemStable

  let maxBBDepth = 7
  let prec = 14
  let searchParams = SP { maximumDepth = fromInteger . toInteger $ maxBBDepth
                           , minimumPrecision = fromInteger . toInteger $ prec }
  results <- PRECiSA.computeAllErrorsInKodiak progSemStable spec searchParams
  -- numerical round-off errors declarations
  let numROErrorsDecl =  summarizeAllStableErrors (getKodiakResults results)

  -- symbolic round-off errors error vars
  let roErrorsDecl = zip (map fst progSemStable) (zip progSymbRoundOffErrs progStableConds)

  -- numerical round-off errors error vars
  funErrEnv <- mapM (computeErrorGuards spec progSemStable) tranProgTuples

  let framaCfileContent = genFramaCFile fp spec realProg decls tranProgTuples roErrorsDecl numROErrorsDecl
                                        funErrEnv progSemStable
  writeFile framaCfile (render framaCfileContent)

  writeFile precisaPreludeFile (render precisaPreludeContent)

  writeFile pvsProgFile (render $ genFpProgFile fp fpFileName decls)

  let symbCertificate = render $ genCertFile fpFileName certFileName inputFileName decls progSemStable
  writeFile certFile symbCertificate

  let numCertificate = render $ genNumCertFile certFileName numCertFileName results decls spec maxBBDepth prec True
  writeFile numCertFile numCertificate

  let guardExpressionsCert = render $ genExprCertFile fp inputFileName fpFileName exprCertFileName (vcat (map (printExprFunCert fp) funErrEnv))
  writeFile exprCertFile guardExpressionsCert
  putStrLn $ "PRECiSA: instrumented C code and PVS certificate generated in " ++ filePath ++ "."

  return ()
    where
      precisaPreludeFile = filePath ++ "precisa_prelude.c"
      inputFileName = takeBaseName fileprog
      fpFileName = inputFileName ++ "_fp"
      filePath = dropFileName fileprog
      framaCfile = filePath ++ inputFileName ++ ".c"
      pvsProgFile = filePath ++ fpFileName ++ ".pvs"
      certFileName = "cert_" ++ inputFileName
      numCertFileName = inputFileName ++ "_num_cert"
      exprCertFileName = inputFileName ++ "_expr_cert"
      exprCertFile = filePath ++ exprCertFileName ++ ".pvs"
      certFile =  filePath ++ certFileName ++ ".pvs"
      numCertFile =  filePath ++ numCertFileName ++ ".pvs"
      semConf = SemConf {improveError = False, assumeTestStability = True, mergeUnstables = True}

initDpsToNone :: Decl -> (FunName, [LDecisionPath])
initDpsToNone (Decl _ _ f _ _) = (f,[])
initDpsToNone (Pred _ _ f _ _) = (f,[])

getKodiakResults :: [(String,PVSType,[Arg],[(Conditions, LDecisionPath,ControlFlow,KodiakResult,AExpr,[FAExpr],[AExpr])])] -> [(String, [(ControlFlow,KodiakResult)])]
getKodiakResults = map getKodiakResult
  where
     getKodiakResult (f,_,_,errors) = (f, map getKodiakError errors)
     getKodiakError (_,_,cf,err,_,_,_) = (cf,err)

summarizeAllStableErrors :: [(String, [(ControlFlow, KodiakResult)])] -> [(String, Double)]
summarizeAllStableErrors errorMap = map aux errorMap
  where
    aux (f, results) = (f,maximum $ map (maximumUpperBound . snd) (filter ((== Stable) . fst) results))
